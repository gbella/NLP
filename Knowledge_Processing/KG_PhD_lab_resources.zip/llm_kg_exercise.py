import os
import sys

from langchain_community.graphs import OntotextGraphDBGraph
from langchain_openai import ChatOpenAI
from langchain.chains import OntotextGraphDBQAChain

model_name="*** MODEL NAME ***"
os.environ["OPENAI_API_KEY"] = "*** OPENROUTER API KEY ***"
query_endpoint="http://localhost:7200/repositories/***_GRAPHDB_REPOSITORY_NAME_***"

graph = OntotextGraphDBGraph(query_endpoint, local_file="fhir_simple_2025.ttl")

chain = OntotextGraphDBQAChain.from_llm(
    ChatOpenAI(temperature=0, \
               openai_api_base="https://openrouter.ai/api/v1",
               model_name=model_name),
    graph=graph,
    verbose=True,
    allow_dangerous_requests=True
)
result = chain.invoke({chain.input_key: sys.argv[1]})
print(result[chain.output_key])
